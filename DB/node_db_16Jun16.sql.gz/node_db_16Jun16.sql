-- phpMyAdmin SQL Dump
-- version 4.4.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 16, 2016 at 11:47 AM
-- Server version: 5.6.25
-- PHP Version: 5.5.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `node`
--
DROP DATABASE `node`;
CREATE DATABASE IF NOT EXISTS `node` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `node`;

-- --------------------------------------------------------

--
-- Table structure for table `activity_log`
--
-- Creation: Jun 16, 2016 at 06:20 AM
--

DROP TABLE IF EXISTS `activity_log`;
CREATE TABLE IF NOT EXISTS `activity_log` (
  `id` int(11) NOT NULL,
  `activity` varchar(254) NOT NULL,
  `notified` int(1) NOT NULL,
  `profile_id` varchar(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `activity_log`
--

INSERT INTO `activity_log` (`id`, `activity`, `notified`, `profile_id`) VALUES
(1, 'test', 0, '1'),
(2, 'new test', 1, '1'),
(3, 'another test', 0, '2');

-- --------------------------------------------------------

--
-- Table structure for table `notes`
--
-- Creation: Jun 15, 2016 at 12:39 PM
--

DROP TABLE IF EXISTS `notes`;
CREATE TABLE IF NOT EXISTS `notes` (
  `id` int(8) NOT NULL,
  `note` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notes`
--

INSERT INTO `notes` (`id`, `note`) VALUES
(1, 'This is a test!'),
(2, 'This is another test...'),
(3, 'And, yet again, another...'),
(4, 'This is a random 33 note'),
(5, 'This is a random 8 note'),
(6, 'This is a random 50 note'),
(7, 'This is a random 70 note'),
(8, 'This is a random 43 note'),
(9, 'This is a random 73 note'),
(10, 'This is a random 80 note'),
(11, 'Sam Note for Test'),
(12, 'This is a random 9 note'),
(13, 'This is a random 44 note'),
(14, 'This is a random 69 note');

-- --------------------------------------------------------

--
-- Table structure for table `session`
--
-- Creation: Jun 16, 2016 at 04:08 AM
--

DROP TABLE IF EXISTS `session`;
CREATE TABLE IF NOT EXISTS `session` (
  `sessionId` varchar(32) COLLATE utf8_bin NOT NULL,
  `expires` int(11) unsigned NOT NULL,
  `data` text COLLATE utf8_bin
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_comments`
--
-- Creation: Jun 16, 2016 at 06:47 AM
--

DROP TABLE IF EXISTS `tbl_comments`;
CREATE TABLE IF NOT EXISTS `tbl_comments` (
  `comment_id` int(11) NOT NULL,
  `article_id` int(11) DEFAULT '0',
  `sender` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_comments`
--

INSERT INTO `tbl_comments` (`comment_id`, `article_id`, `sender`, `body`, `created_at`) VALUES
(1, 48, 'Sam', 'First Comment', '2016-06-16 12:23:27'),
(2, 48, 'Sam1', 'Second Comment', '2016-06-16 12:23:37'),
(3, 48, 'Sam', 'New Comment', '2016-06-16 12:25:20'),
(4, 49, 'Max', 'First Comment for Max', '2016-06-16 12:25:45'),
(5, 47, 'abc', 'First for abc', '2016-06-16 12:53:18'),
(6, 47, 'abc', 'second for abc', '2016-06-16 12:53:32'),
(7, 48, 'Sam', 'Fourth Comments\n', '2016-06-16 12:56:12'),
(8, 48, 'sam', 'another comment', '2016-06-16 12:58:49'),
(9, 48, 'sam ', 'yet another', '2016-06-16 12:59:15'),
(10, 48, 'max', 'final comment\n', '2016-06-16 13:11:32'),
(11, 49, 'sam', 'new\ntest', '2016-06-16 14:16:57'),
(12, 49, 'sam', 'new\ntest', '2016-06-16 14:22:36'),
(13, 49, 'adf', 'adf', '2016-06-16 14:24:56'),
(14, 49, 'adf', 'adsf', '2016-06-16 14:37:42'),
(15, 47, 'Sam', 'Test', '2016-06-16 14:38:31'),
(16, 47, 'adsf', 'asdf', '2016-06-16 14:39:44'),
(17, 47, 'afd', 'asdf', '2016-06-16 14:40:30'),
(18, 47, 'sfg', 'gf', '2016-06-16 14:41:09'),
(19, 47, 'adf', 'adf', '2016-06-16 14:42:13'),
(20, 47, 'adsf', 'afd', '2016-06-16 14:42:32');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notes`
--
ALTER TABLE `notes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `session`
--
ALTER TABLE `session`
  ADD PRIMARY KEY (`sessionId`);

--
-- Indexes for table `tbl_comments`
--
ALTER TABLE `tbl_comments`
  ADD PRIMARY KEY (`comment_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_log`
--
ALTER TABLE `activity_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `notes`
--
ALTER TABLE `notes`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `tbl_comments`
--
ALTER TABLE `tbl_comments`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
